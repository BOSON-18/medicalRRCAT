import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.gridfs.GridFSDownloadStream;
import org.bson.types.ObjectId;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet(name = "PDFDownloadServletMon", urlPatterns = {"/servlet/PDFDownloadServletMon", "/catintra/servlet/PDFDownloadServletMon"}) 
public class PDFDownloadServletMon extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fileId = request.getParameter("id");
        if (fileId != null) {
            try (MongoClient mongoClient = MongoClients.create("mongodb://10.10.18.182:27017/")) {
                MongoDatabase database = mongoClient.getDatabase("medical");
                GridFSBucket gridFSBucket = GridFSBuckets.create(database);

                // Get the GridFS file by its ID
                ObjectId objectId = new ObjectId(fileId);
                GridFSDownloadStream downloadStream = gridFSBucket.openDownloadStream(objectId);

                // Set the response content type to PDF
                response.setContentType("application/pdf");
                response.setHeader("Content-Disposition", "inline; filename=\"file.pdf\"");

                // Write the PDF stream to the response output stream
                try (OutputStream out = response.getOutputStream()) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = downloadStream.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                }
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "File ID is required");
        }
    }
}