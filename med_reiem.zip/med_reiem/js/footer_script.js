        let pdfDoc = null; // Holds the loaded PDF document
        let currentPage = 1; // Tracks the current page number

        // Function to render a page from the PDF
        function renderPage(pageNum) {
            pdfDoc.getPage(pageNum).then(function(page) {
                //const scale = 1.5;  // Scale factor to control size of the rendered page
                const scale = 3;  // Scale factor to control size of the rendered page
                const viewport = page.getViewport({ scale: scale });

                const canvas = document.getElementById('pdfViewer');
                const context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;

                // Render the page onto the canvas
                page.render({
                    canvasContext: context,
                    viewport: viewport
                });

                // Update the page number display
                //document.getElementById('pageNumber').textContent = `Page ${currentPage}`;
                document.getElementById('pageNumber').textContent =  currentPage;
                document.getElementById('pageTot').textContent = pdfDoc.numPages;
                
                // Enable/disable navigation buttons based on current page
                document.getElementById('prevPage').disabled = currentPage === 1;
                document.getElementById('nextPage').disabled = currentPage === pdfDoc.numPages;
            });
        }

        // Function to load the PDF document and initialize rendering
        document.getElementById('pdfInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file && file.type === 'application/pdf') {
                const reader = new FileReader();

                reader.onload = function(e) {
                    const pdfData = new Uint8Array(e.target.result);
                    
                    const loadingTask = pdfjsLib.getDocument(pdfData);
                    loadingTask.promise.then(function(pdf) {
                        pdfDoc = pdf; // Store the loaded PDF document

                        // Initially render the first page
                        //renderPage(currentPage);
												
                        renderPage(1);
												//document.getElementById('pageNumber').textContent = 1;
                        // Enable the navigation buttons once the PDF is loaded
                        document.getElementById('prevPage').disabled = true;
                        document.getElementById('nextPage').disabled = pdf.numPages === 1;
                    }).catch(function(error) {
                        console.error('Error loading PDF: ', error);
                    });
                };

                // Read the file as an ArrayBuffer
                reader.readAsArrayBuffer(file);
            } else {
                alert('Please upload a valid PDF file');
            }
        });

        // Previous page button handler
        document.getElementById('prevPage').addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                renderPage(currentPage);
            }
        });

        // Next page button handler
        document.getElementById('nextPage').addEventListener('click', function() {
            if (currentPage < pdfDoc.numPages) {
                currentPage++;
                renderPage(currentPage);
            }
        });