       // Function to add a new bill entry
        function addBill() {
            var billContainer = document.getElementById("bill-container");
            var newBillDiv = document.createElement("tr");
            newBillDiv.innerHTML = '<td><input type="date" name="bill_date[]" required></td>								<td><input type="number" name="bill_amt[]" step="0.01" required oninput="calculateTotal()"></td><td><input type="text" name="store_name[]" required>&nbsp;&nbsp;<font style="font-size:22px;color:red;cursor:pointer;font-weight:bold;" title="Remove Bill" onclick="removeBill(this)">[-]</font></td>';
            
            billContainer.appendChild(newBillDiv);
        }
        function addMed() {
            var billContainer = document.getElementById("bill-container-dis");
            var newBillDiv = document.createElement("tr");
            newBillDiv.innerHTML = '<td><input type="number" name="dis_amt[]" step="0.01" required oninput="calculateTotalDis()"></td><td><input type="text" name="med_name[]" required></td><td><input type="text" name="dis_res[]" required>&nbsp;&nbsp;<font style="font-size:22px;color:red;cursor:pointer;font-weight:bold;" title="Remove Medicine" onclick="removeMed(this)">[-]</font></td>';
            
            billContainer.appendChild(newBillDiv);
        }

        // Function to remove a bill entry
        function removeBill(button) {
            var billEntry = button.parentElement.parentElement;
            billEntry.remove();
						calculateTotal();
        }
        function removeMed(button) {
            var billEntry = button.parentElement.parentElement;
            billEntry.remove();
						calculateTotalDis();
        }
        function calculateTotal() {
            var total = 0;
            var billAmounts = document.getElementsByName("bill_amt[]");
            
            // Loop through each bill amount and add it to the total
            for (var i = 0; i < billAmounts.length; i++) {
                var billAmount = parseFloat(billAmounts[i].value);
                if (!isNaN(billAmount)) {
                    total += billAmount;
                }
            }

            // Display the total sum in a span with id 'total-amount'
            document.getElementById("claim_amt").value = total.toFixed(2);
        }
        function calculateTotalDis() {
            var total = 0;
            var billAmounts = document.getElementsByName("dis_amt[]");
            
            // Loop through each bill amount and add it to the total
            for (var i = 0; i < billAmounts.length; i++) {
                var billAmount = parseFloat(billAmounts[i].value);
                if (!isNaN(billAmount)) {
                    total += billAmount;
                }
            }

            // Display the total sum in a span with id 'total-amount'
            document.getElementById("appr_amt").value = document.getElementById("claim_amt").value - total.toFixed(2);
        }